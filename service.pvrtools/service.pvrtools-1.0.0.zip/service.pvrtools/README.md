service.pvrtools
================

A simple addon to extend kodi iptv simple pvr addon
